/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pincipal;

/**
 *
 * @author Will
 */
public class Pincipal {

        public static void main(String[] args) {
        // Glicemia
        Glicemia glicemia = new Glicemia();
        
        glicemia.registerExam();
        glicemia.showResult();
        
        // Colesterol
        Colesterol colesterol = new Colesterol();
        
        colesterol.registerExam();
        colesterol.showResult();
        
        // Triglicerideos
        Triglicerideos triglicerideos = new Triglicerideos();
        
        triglicerideos.registerExam();
        triglicerideos.showResult();
    }
}

